import functions_framework

@functions_framework.http
def main(request):
    return "Hello World", 200
